# Validation pairs — tier1/B0 (random 20)

Manual inspection gate (§8.1). L1 = script-preserving (headline metric), L2 = script-invariant (secondary).

### 957491_4xyIm2P6Xzlin341_0129  (6.49s)
* WER 0.54 — sub 3 ins 0 del 4; B-errors 2/2 U-errors 5/11
* `REF L1` send पर क्लिक करें आपका ईमेल भेजा जा चुका है इसे जांच लें
* `HYP L1` आपका इमेल भेजा जा चुका है इसे जॉनस ले
* `REF L2` send par klik karen apak imel bej ja kuk hi ise jank len
* `HYP L2` apak imel bej ja kuk hi ise jonas le

### 921151_kvxzesc5pGxL6dnk_0042  (2.79s)
* WER 0.75 — sub 4 ins 0 del 2; B-errors 4/4 U-errors 2/4
* `REF L1` अंत में editor font button पर click करें
* `HYP L1` एडिटर फॉंट बटन पर क्लिक करें
* `REF L2` ant men editor font buton par klik karen
* `HYP L2` editar font batan par klik karen

### 323507_HgEJsLGKNWSFl8T7_0110  (7.72s)
* WER 0.90 — sub 1 ins 8 del 0; B-errors 1/1 U-errors 8/9
* `REF L1` अधिक जानकारी के लिए कृपया contact spokentutorial org पर लिखें
* `HYP L1` उनको प्रमाण पत्र भी देते हैं अधिक जानकारी के लिए कृपया contact at spoken tutorial org पर लिखें
* `REF L2` adik janakari ke le kripai kontakt spokentutoral org par liken
* `HYP L2` unako praman patr bi det hin adik janakari ke le kripai kontakt at spoken tutoral org par liken

### 137494_fpL6MBSZsci9dyAn_0050  (4.77s)
* WER 0.33 — sub 3 ins 0 del 0; B-errors 0/0 U-errors 3/9
* `REF L1` केवल हमारे द्वारा टैग किये मैसेजेस प्रदर्शित होते हैं
* `HYP L1` केवल हमारे द्वारा tag की messages प्रदर्शित होते हैं
* `REF L2` keval hamar dvar tig kii misejes pradarshit hot hin
* `HYP L2` keval hamar dvar tag ki mesajes pradarshit hot hin

### 834022_lHGLSlYIb1clRBRF_0004  (7.02s)
* WER 0.17 — sub 3 ins 0 del 0; B-errors 1/4 U-errors 2/14
* `REF L1` उद्घोषक को reference notes के जरिये मदद करने के लिए जब वह दर्शक के सामने slides प्रस्तुत करे
* `HYP L1` उद्घोशक को reference notes के जरीए मदद करने के लिए जब वह दर्शक के सामने slides प्रस्तुत करें
* `REF L2` udgoshak ko referens notes ke jarii madad karan ke le jab vah darshak ke saman slides prastut kar
* `HYP L2` udgoshak ko referens notes ke jar madad karan ke le jab vah darshak ke saman slides prastut karen

### 347099_K5BlLYB9ynemLTVa_0044  (5.45s)
* WER 0.17 — sub 2 ins 0 del 0; B-errors 1/4 U-errors 1/8
* `REF L1` general टैब में print के अंदर document field में notes option चुनें
* `HYP L1` general टैब में print के अंदर document फील्ड में notes ओप्शन चुनें
* `REF L2` jeneral tib men print ke andar dokument feld men notes opshan kunen
* `HYP L2` jeneral tib men print ke andar dokument fild men notes opshan kunen

### 508088_RRrEfkw4Rh5TdJkS_0092  (2.48s)
* WER 0.88 — sub 6 ins 0 del 1; B-errors 1/1 U-errors 6/7
* `REF L1` यह spoken tutorial project का सार देता है
* `HYP L1` यदि आपके पास अच्छा bandwidth नहीं है
* `REF L2` yah spoken tutoral projekt ka sar det hi
* `HYP L2` yadi apak pas aka bandvidt nahin hi

### 360746_4oLp3bc9OSJbDrwM_0007  (5.88s)
* WER 0.31 — sub 4 ins 0 del 0; B-errors 1/1 U-errors 3/12
* `REF L1` यह commands के लिए alias यानी उपनाम परिभाषित करने का 1 तरीका है
* `HYP L1` यह कमांड के लिए एलियस यानि उपनाम परिभाशित करने का 1 तरीका है
* `REF L2` yah komands ke le alas yani upanan paribashit karan ka 1 tarik hi
* `HYP L2` yah kamand ke le eliyas yani upanan paribashit karan ka 1 tarik hi

### 508088_RRrEfkw4Rh5TdJkS_0067  (5.64s)
* WER 0.08 — sub 1 ins 0 del 0; B-errors 1/4 U-errors 0/9
* `REF L1` all pages option document के सभी पेजेस को प्रिंट करने के लिए है
* `HYP L1` all pages option डॉक्यूमेंट के सभी पेजेस को प्रिंट करने के लिए है
* `REF L2` al pajes opshan dokument ke sabi pejes ko print karan ke le hi
* `HYP L2` al pajes opshan dokyument ke sabi pejes ko print karan ke le hi

### 628028_K8YJLqIcMPJ5GftE_0141  (2.44s)
* WER 0.00 — sub 0 ins 0 del 0; B-errors 0/0 U-errors 0/6
* `REF L1` 1 मौजूदा एड्रेस बुक डिलीट करें
* `HYP L1` 1 मौजूदा एड्रेस बुक डिलीट करें
* `REF L2` 1 mujud edres buk dilit karen
* `HYP L2` 1 mujud edres buk dilit karen

### 791308_kGQKLyQ1HtnUNL1d_0051  (4.04s)
* WER 0.57 — sub 4 ins 0 del 0; B-errors 1/2 U-errors 3/5
* `REF L1` default रूप से american english चयनित है
* `HYP L1` डिफॉल्ट रूप से अमेरिकन इंग्लिश चैनित है
* `REF L2` defult rup se amerikan english kayanit hi
* `HYP L2` difolt rup se amerikan inglish kinit hi

### 656852_dNHXkqqVPqWYhzis_0079  (10.15s)
* WER 1.70 — sub 2 ins 15 del 0; B-errors 1/2 U-errors 16/8
* `REF L1` हमारी team में से कोई भी 1 उसका जवाब देगा
* `HYP L1` मिनट और सेकंड को चुनें जहां आपको समस्या है अपने सवाल को संशेप में समझाएं हमारी टीम में से कोई भी 1 उसका जबाब देगा
* `REF L2` hamari tan men se ki bi 1 usak javab deg
* `HYP L2` minat ura sekand ko kunen jahan apako samasi hi apan saval ko sanshep men samajen hamari tin men se ki bi 1 usak jabab deg

### 957491_4xyIm2P6Xzlin341_0159  (8.03s)
* WER 0.33 — sub 5 ins 0 del 0; B-errors 1/1 U-errors 4/14
* `REF L1` यह अकाऊंट का उपयोग करके मेल्स भेजें और प्राप्त करें निरीक्षण करें क्या होता है
* `HYP L1` इस अकाउंट का उप्योग करके मेल्स भेजे और प्राप्त करें निरीशन करें क्या होता है
* `REF L2` yah akunt ka upayog karak mels bejen ura prapt karen nirikshan karen kya hot hi
* `HYP L2` isa akunt ka upyog karak mels bej ura prapt karen nirishan karen kya hot hi

### 628028_K8YJLqIcMPJ5GftE_0151  (1.68s)
* WER 0.00 — sub 0 ins 0 del 0; B-errors 0/1 U-errors 0/3
* `REF L1` spoken tutorial project team
* `HYP L1` spoken tutorial project team
* `REF L2` spoken tutoral projekt tan
* `HYP L2` spoken tutoral projekt tan

### 137494_fpL6MBSZsci9dyAn_0159  (5.74s)
* WER 0.33 — sub 1 ins 2 del 0; B-errors 0/1 U-errors 3/8
* `REF L1` अधिक जानकारी के लिए contact spokentutorial org पर लिखें
* `HYP L1` अधिक जानकारी के लिए contact at spoken tutorial org पर लिखें
* `REF L2` adik janakari ke le kontakt spokentutoral org par liken
* `HYP L2` adik janakari ke le kontakt at spoken tutoral org par liken

### 598753_406yMKxIdSDHRf8H_0057  (6.89s)
* WER 0.39 — sub 6 ins 1 del 0; B-errors 4/4 U-errors 3/14
* `REF L1` जैसे ही आप control point पर अपना cursor घुमाते हैं cursor 1 doublesided arrow में परिवर्तित होता है
* `HYP L1` जैसे ही आप कंट्रोल पॉइंट पर अपना करसर घुमाते हैं करसर 1 डबल साइडेड एरो में परिवर्तित होता है
* `REF L2` jis hi apa kontrol pint par apan kursor gumat hin kursor 1 dublesided arov men parivartit hot hi
* `HYP L2` jis hi apa kantrol pint par apan karasar gumat hin karasar 1 dabal sided ero men parivartit hot hi

### 323507_HgEJsLGKNWSFl8T7_0045  (9.08s)
* WER 0.14 — sub 2 ins 1 del 0; B-errors 0/5 U-errors 3/16
* `REF L1` यहां इन options के लिए shortcut कीज भी हैंcopy करने के लिए ctrl c और paste करने के लिए ctrl v
* `HYP L1` यहां इन options के लिए shortcut keys भी है copy करने के लिए ctrl c और paste करने के लिए ctrl v
* `REF L2` yahan ina opshans ke le shortkut kij bi hinkopi karan ke le ktrl k ura past karan ke le ktrl v
* `HYP L2` yahan ina opshans ke le shortkut keys bi hi kopi karan ke le ktrl k ura past karan ke le ktrl v

### 521245_Psh5UDSFbhWLZ3gk_0122  (3.06s)
* WER 0.82 — sub 2 ins 0 del 7; B-errors 0/0 U-errors 9/11
* `REF L1` थंडरबर्ड की 1 और लाभदायक विशेषता है जंक मैसेजेस को पहचानना
* `HYP L1` जंक मैसेज को बहचानना
* `REF L2` tandarabard ki 1 ura labadayak visheshat hi jank misejes ko pahakanan
* `HYP L2` jank misej ko bahakanan

### 656852_dNHXkqqVPqWYhzis_0061  (7.35s)
* WER 0.30 — sub 5 ins 1 del 0; B-errors 3/4 U-errors 3/16
* `REF L1` अन्यथा आप बदलाव को सेव करने के लिए toolbar में नीचे की ओर arrow icon पर click कर सकते हैं
* `HYP L1` अन्यथा आप बदलाब को सेव करने के लिए तूल बार में नीचे की ओर एरो आइकन पर क्लिक कर सकते हैं
* `REF L2` anyat apa badalav ko sev karan ke le tolbar men nik ki ora arov ikon par klik kar sakat hin
* `HYP L2` anyat apa badalab ko sev karan ke le tul bar men nik ki ora ero ikan par klik kar sakat hin

### 388577_LPGZ2Jo8uBX4sx76_0082  (5.04s)
* WER 0.23 — sub 3 ins 0 del 0; B-errors 3/3 U-errors 0/10
* `REF L1` इसके अलावा line जिस पर cursor है bold में प्रदर्शित हो रहा है
* `HYP L1` इसके अलावा लाइन जिस पर करसर है बोल्ड में प्रदर्शित हो रहा है
* `REF L2` isak alav lin jis par kursor hi bold men pradarshit ho rah hi
* `HYP L2` isak alav lin jis par karasar hi bold men pradarshit ho rah hi
