# Results — tier2

Model `large-v3` (float16, beam 5, temperature 0.0, language `hi`). Headline WER is level-1 (script-preserving) normalisation; WER-L2 is the script-invariant secondary metric. B-WER / U-WER split errors by whether the reference word is in the frozen syllabus lexicon. p-values are one-sided paired bootstrap against B0.

| System | What it isolates | N | WER | ΔWER | p | B-WER | ΔB | p | U-WER | ΔU | p | CER | WER-L2 | Term F1 | %impr | %regr |
|---|---|--:|--:|--:|--:|--:|--:|--:|--:|--:|--:|--:|--:|--:|--:|--:|
| B0  baseline, no grounding | reference point | 800 | 0.4562 | — | — | 0.6184 | — | — | 0.4122 | — | — | 0.3724 | 0.3922 | 0.4983 | — | — |
| C1  generic non-syllabus context | effect of conditioning per se | 800 | 0.3956 | -0.0606 | 0.000 | 0.4087 | -0.2097 | 0.000 | 0.3920 | -0.0202 | 0.000 | 0.3123 | 0.3533 | 0.6414 | 39.6 | 13.2 |
| C2  random syllabus document | whether the correct syllabus matters | 800 | 0.6966 | 0.2404 | 1.000 | 0.8065 | 0.1881 | 0.996 | 0.6668 | 0.2546 | 1.000 | 0.6328 | 0.6501 | 0.4981 | 28.8 | 36.6 |
| C3  oracle syllabus document | upper bound given perfect retrieval | 800 | 0.6911 | 0.2349 | 1.000 | 0.7189 | 0.1004 | 0.991 | 0.6835 | 0.2713 | 1.000 | 0.6017 | 0.6480 | 0.5363 | 27.2 | 41.1 |
| M1  retrieved context conditioning | mechanism 1 | 800 | 0.5408 | 0.0846 | 1.000 | 0.5958 | -0.0226 | 0.136 | 0.5258 | 0.1136 | 1.000 | 0.4605 | 0.4919 | 0.5620 | 30.0 | 29.0 |
| M1' glossary-style context (ablation) | prose vs glossary (§7.1) | 800 | 0.4786 | 0.0224 | 0.816 | 0.6672 | 0.0487 | 0.632 | 0.4274 | 0.0152 | 0.992 | 0.4032 | 0.4267 | 0.5496 | 26.8 | 20.8 |
| M1'' per-utterance retrieval (ablation) | retrieval granularity (§6.4) | 800 | 0.5629 | 0.1067 | 1.000 | 0.6302 | 0.0118 | 0.705 | 0.5447 | 0.1325 | 1.000 | 0.4822 | 0.5136 | 0.5513 | 29.9 | 31.1 |
| M2  retrieved token-level biasing | mechanism 2 | 800 | 0.4192 | -0.0370 | 0.000 | 0.4579 | -0.1605 | 0.000 | 0.4087 | -0.0035 | 0.176 | 0.3286 | 0.3722 | 0.6129 | 28.1 | 11.5 |
| M3a lexical correction on B0 | mechanism 3 (deterministic) | 800 | 0.4557 | -0.0005 | 0.369 | 0.6032 | -0.0153 | 0.006 | 0.4157 | 0.0035 | 1.000 | 0.3692 | 0.3942 | 0.5010 | 7.8 | 6.8 |
| M1+M3a  context + correction | complementarity (H3) | 800 | 0.5440 | 0.0878 | 1.000 | 0.6032 | -0.0153 | 0.242 | 0.5280 | 0.1158 | 1.000 | 0.4613 | 0.4971 | 0.5508 | 29.8 | 30.6 |
| M2+M3a  biasing + correction | complementarity (H3) | 800 | 0.4243 | -0.0319 | 0.000 | 0.4618 | -0.1566 | 0.000 | 0.4141 | 0.0019 | 0.690 | 0.3314 | 0.3791 | 0.5984 | 29.2 | 14.8 |
| G   confidence-gated biasing | principal contribution (H4) | 800 | 0.4192 | -0.0370 | 0.000 | 0.4579 | -0.1605 | 0.000 | 0.4087 | -0.0035 | 0.176 | 0.3286 | 0.3722 | 0.6129 | 28.1 | 11.5 |

## Error composition and guards

| System | sub | ins | del | Term P | Term R | echo-guard rate | rewrite-discard rate | grounded rate |
|---|--:|--:|--:|--:|--:|--:|--:|--:|
| B0 | 2655 | 1041 | 647 | 0.5169 | 0.4810 | — | — | — |
| C1 | 2104 | 1002 | 660 | 0.5886 | 0.7046 | 0.024 | — | — |
| C2 | 2813 | 3206 | 613 | 0.4254 | 0.6007 | 0.021 | — | — |
| C3 | 3036 | 2880 | 663 | 0.4648 | 0.6337 | 0.016 | — | — |
| M1 | 2518 | 2075 | 555 | 0.5094 | 0.6268 | 0.003 | — | — |
| M1_glossary | 2531 | 1381 | 644 | 0.4900 | 0.6258 | 0.000 | — | — |
| M1_utterance | 2413 | 2410 | 536 | 0.4957 | 0.6209 | 0.004 | — | — |
| M2 | 2321 | 1010 | 660 | 0.5803 | 0.6494 | 0.000 | — | — |
| M3a | 2657 | 1030 | 651 | 0.4964 | 0.5057 | — | — | — |
| M1+M3a | 2559 | 2060 | 560 | 0.4868 | 0.6342 | 0.003 | — | — |
| M2+M3a | 2371 | 1002 | 666 | 0.5523 | 0.6529 | 0.000 | — | — |
| G | 2321 | 1010 | 660 | 0.5803 | 0.6494 | 0.000 | — | 1.000 |

## Measured context

* Retrieval top-1 topic accuracy (lecture_k3): **0.802** (§6.3).
* Headroom: 1580 of 4343 word errors (36.4%) touch a syllabus lexicon term. Terminology biasing can therefore reduce overall WER by at most that share, and only to the extent it repairs those errors without introducing new ones.
* Lexicon coverage on this tier: 21.3% of reference word tokens are lexicon terms (2031/9520); §5.4.
